from django.apps import AppConfig


class WebapimdConfig(AppConfig):
    name = 'webapimd'
