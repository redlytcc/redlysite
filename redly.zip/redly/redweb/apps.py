from django.apps import AppConfig


class RedwebConfig(AppConfig):
    name = 'redweb'
